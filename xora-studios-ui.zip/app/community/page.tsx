'use client';

import { Header } from '@/components/Header';
import { MobileNav } from '@/components/MobileNav';
import { Heart, MessageCircle, Share2 } from 'lucide-react';

const communityPosts = [
  {
    id: 1,
    author: 'Alex Nova',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop',
    content: 'Just finished Nexus Protocol. Mind blown! The AI performances were incredibly natural.',
    timestamp: '2 hours ago',
    likes: 342,
    comments: 45,
    image: 'https://images.unsplash.com/photo-1633356122544-f134324ef6db?w=400&h=300&fit=crop',
  },
  {
    id: 2,
    author: 'Maya Chen',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop',
    content: 'The new AI Generated Originals are absolutely stunning. This is the future of cinema!',
    timestamp: '4 hours ago',
    likes: 567,
    comments: 89,
  },
  {
    id: 3,
    author: 'Isaac Moore',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop',
    content: 'Watching Cipher Origins again. Every scene is a masterpiece. The cinematography is insane.',
    timestamp: '6 hours ago',
    likes: 234,
    comments: 32,
    image: 'https://images.unsplash.com/photo-1598899134739-24c46f58b8c0?w=400&h=300&fit=crop',
  },
];

export default function CommunityPage() {
  return (
    <div className="min-h-screen bg-background text-foreground pb-24 md:pb-8">
      <Header />

      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        {/* Header */}
        <div className="space-y-4">
          <h1 className="text-4xl font-bold text-foreground">Community Feed</h1>
          <p className="text-foreground/60">Connect with other XORA Studios enthusiasts</p>
        </div>

        {/* Share Post Section */}
        <div className="glass-card border rounded-xl p-6">
          <div className="flex gap-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-secondary flex-shrink-0" />
            <div className="flex-1 space-y-3">
              <textarea
                placeholder="What are you watching today?"
                className="w-full bg-card/40 border border-border/50 rounded-lg px-4 py-3 text-foreground placeholder:text-foreground/50 focus:outline-none focus:ring-2 focus:ring-accent focus:bg-card/60 smooth-transition resize-none"
                rows={3}
              />
              <button className="glass-button px-6 py-2 rounded-lg font-semibold">
                Share
              </button>
            </div>
          </div>
        </div>

        {/* Posts Feed */}
        <div className="space-y-6">
          {communityPosts.map((post) => (
            <div key={post.id} className="glass-card border rounded-xl p-6 space-y-4">
              {/* Post Header */}
              <div className="flex items-center gap-3">
                <img
                  src={post.avatar}
                  alt={post.author}
                  className="w-12 h-12 rounded-full object-cover border border-primary/30"
                />
                <div className="flex-1">
                  <h3 className="font-bold text-foreground">{post.author}</h3>
                  <p className="text-sm text-foreground/50">{post.timestamp}</p>
                </div>
              </div>

              {/* Post Content */}
              <p className="text-foreground/90">{post.content}</p>

              {/* Post Image */}
              {post.image && (
                <img
                  src={post.image}
                  alt="Post content"
                  className="w-full rounded-lg object-cover max-h-96"
                />
              )}

              {/* Post Actions */}
              <div className="flex items-center justify-between pt-4 border-t border-border/30">
                <button className="flex items-center gap-2 text-foreground/60 hover:text-accent smooth-transition group">
                  <Heart className="w-5 h-5 group-hover:fill-accent" />
                  <span className="text-sm">{post.likes}</span>
                </button>
                <button className="flex items-center gap-2 text-foreground/60 hover:text-accent smooth-transition">
                  <MessageCircle className="w-5 h-5" />
                  <span className="text-sm">{post.comments}</span>
                </button>
                <button className="flex items-center gap-2 text-foreground/60 hover:text-accent smooth-transition">
                  <Share2 className="w-5 h-5" />
                  <span className="text-sm">Share</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Load More */}
        <button className="w-full glass-button py-3 rounded-lg font-semibold">
          Load More Posts
        </button>
      </main>

      <MobileNav />
    </div>
  );
}
