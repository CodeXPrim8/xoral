'use client';

import { Header } from '@/components/Header';
import { MobileNav } from '@/components/MobileNav';
import { FeaturedGrid } from '@/components/FeaturedGrid';
import { trendingMovies } from '@/lib/data';

export default function MoviesPage() {
  return (
    <div className="min-h-screen bg-background text-foreground pb-24 md:pb-8">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        {/* Header */}
        <div className="space-y-4">
          <h1 className="text-4xl md:text-5xl font-black text-foreground">All Movies</h1>
          <p className="text-lg text-foreground/70">Explore our vast collection of films and series</p>
        </div>

        {/* Filters/Search Section */}
        <div className="glass-card p-6 rounded-xl border space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <input
              type="text"
              placeholder="Search movies..."
              className="flex-1 bg-input/50 border border-border rounded-lg px-4 py-2 text-foreground placeholder:text-foreground/50 focus:outline-none focus:ring-2 focus:ring-accent smooth-transition"
            />
            <select className="bg-input/50 border border-border rounded-lg px-4 py-2 text-foreground focus:outline-none focus:ring-2 focus:ring-accent smooth-transition">
              <option>All Genres</option>
              <option>Sci-Fi</option>
              <option>Thriller</option>
              <option>Drama</option>
              <option>Action</option>
            </select>
            <select className="bg-input/50 border border-border rounded-lg px-4 py-2 text-foreground focus:outline-none focus:ring-2 focus:ring-accent smooth-transition">
              <option>Latest</option>
              <option>Most Popular</option>
              <option>Highest Rated</option>
              <option>Trending</option>
            </select>
          </div>
        </div>

        {/* Movies Grid */}
        <FeaturedGrid
          title="Featured Movies"
          items={[...trendingMovies, ...trendingMovies, ...trendingMovies]}
        />
      </main>

      <MobileNav />
    </div>
  );
}
