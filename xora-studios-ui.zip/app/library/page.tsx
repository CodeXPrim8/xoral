'use client';

import { useState } from 'react';
import { Header } from '@/components/Header';
import { MobileNav } from '@/components/MobileNav';
import { ContentCard } from '@/components/ContentCard';
import { Bookmark, Clock, Check } from 'lucide-react';
import { continueWatching, trendingMovies } from '@/lib/data';

export default function LibraryPage() {
  const [activeTab, setActiveTab] = useState<'continue' | 'watchlist' | 'watched'>('continue');

  return (
    <div className="min-h-screen bg-background text-foreground pb-24 md:pb-8">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        {/* Header */}
        <div className="space-y-4">
          <div className="flex items-center gap-3 mb-2">
            <Bookmark className="w-8 h-8 text-accent" />
            <h1 className="text-4xl font-bold text-foreground">My Library</h1>
          </div>
          <p className="text-foreground/60">Your personal collection of movies and series</p>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 border-b border-border/30">
          {[
            { id: 'continue', label: 'Continue Watching', icon: Clock },
            { id: 'watchlist', label: 'Watchlist', icon: Bookmark },
            { id: 'watched', label: 'Watched', icon: Check },
          ].map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id as any)}
              className={`flex items-center gap-2 px-4 py-3 font-semibold border-b-2 smooth-transition ${
                activeTab === id
                  ? 'border-accent text-accent'
                  : 'border-transparent text-foreground/60 hover:text-foreground'
              }`}
            >
              <Icon className="w-4 h-4" />
              {label}
            </button>
          ))}
        </div>

        {/* Content Grid */}
        <div>
          {activeTab === 'continue' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {continueWatching.map((item) => (
                  <ContentCard key={item.id} {...item} />
                ))}
              </div>
            </div>
          )}

          {activeTab === 'watchlist' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {trendingMovies.slice(0, 8).map((item) => (
                  <ContentCard key={item.id} {...item} />
                ))}
              </div>
            </div>
          )}

          {activeTab === 'watched' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {trendingMovies.map((item) => (
                  <ContentCard key={item.id} {...item} />
                ))}
              </div>
            </div>
          )}
        </div>
      </main>

      <MobileNav />
    </div>
  );
}
