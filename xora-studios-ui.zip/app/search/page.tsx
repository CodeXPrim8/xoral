'use client';

import { Header } from '@/components/Header';
import { MobileNav } from '@/components/MobileNav';
import { ContentCard } from '@/components/ContentCard';
import { Search } from 'lucide-react';
import { useState } from 'react';
import { trendingMovies, aiMovies } from '@/lib/data';

export default function SearchPage() {
  const [searchQuery, setSearchQuery] = useState('');

  const allContent = [...trendingMovies, ...aiMovies];
  const filteredContent = searchQuery
    ? allContent.filter((item) =>
        item.title.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  return (
    <div className="min-h-screen bg-background text-foreground pb-24 md:pb-8">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        {/* Search Header */}
        <div className="space-y-6">
          <div>
            <h1 className="text-4xl font-bold text-foreground mb-2">Search</h1>
            <p className="text-foreground/60">Find your next favorite movie or series</p>
          </div>

          {/* Search Input */}
          <div className="relative">
            <Search className="absolute left-4 top-3 w-5 h-5 text-foreground/50" />
            <input
              type="text"
              placeholder="Search by title, actor, or genre..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-card/40 border border-border/50 rounded-lg pl-12 pr-4 py-3 text-foreground placeholder:text-foreground/50 focus:outline-none focus:ring-2 focus:ring-accent focus:bg-card/60 smooth-transition text-lg"
              autoFocus
            />
          </div>
        </div>

        {/* Search Results */}
        {searchQuery ? (
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-6">
              {filteredContent.length > 0
                ? `Found ${filteredContent.length} result${filteredContent.length !== 1 ? 's' : ''}`
                : 'No results found'}
            </h2>
            {filteredContent.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {filteredContent.map((item) => (
                  <ContentCard key={item.id} {...item} />
                ))}
              </div>
            ) : (
              <div className="glass-card border rounded-xl p-12 text-center">
                <p className="text-foreground/60 text-lg">
                  Try searching for something else
                </p>
              </div>
            )}
          </div>
        ) : (
          <div className="glass-card border rounded-xl p-12 text-center">
            <Search className="w-12 h-12 text-foreground/30 mx-auto mb-4" />
            <p className="text-foreground/60 text-lg">
              Start typing to search for movies, series, and more
            </p>
          </div>
        )}
      </main>

      <MobileNav />
    </div>
  );
}
