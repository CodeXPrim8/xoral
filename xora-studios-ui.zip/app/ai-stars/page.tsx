'use client';

import { Header } from '@/components/Header';
import { MobileNav } from '@/components/MobileNav';
import { ContentCard } from '@/components/ContentCard';
import { aiMovies } from '@/lib/data';
import { Sparkles } from 'lucide-react';

export default function AIStarsPage() {
  const aiStars = [
    {
      id: 'ai-star-1',
      name: 'NOVA',
      description: 'Advanced AI actress specializing in dramatic performances',
      image: 'https://images.unsplash.com/photo-1520763185298-1b434c919abe?w=300&h=300&fit=crop',
      appearances: 12,
    },
    {
      id: 'ai-star-2',
      name: 'CIPHER',
      description: 'AI actor known for action and thriller roles',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=300&fit=crop',
      appearances: 8,
    },
    {
      id: 'ai-star-3',
      name: 'AURORA',
      description: 'Versatile AI performer in sci-fi and fantasy',
      image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&h=300&fit=crop',
      appearances: 15,
    },
    {
      id: 'ai-star-4',
      name: 'QUANTUM',
      description: 'Cutting-edge AI talent in futuristic narratives',
      image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&h=300&fit=crop',
      appearances: 10,
    },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground pb-24 md:pb-8">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
        {/* Hero Section */}
        <div className="space-y-4">
          <div className="flex items-center gap-3 mb-2">
            <Sparkles className="w-8 h-8 text-accent" />
            <h1 className="text-4xl md:text-5xl font-black text-foreground">AI Stars</h1>
          </div>
          <p className="text-lg text-foreground/70 max-w-2xl">
            Discover the artificial intelligence actors revolutionizing cinema. These digital performers bring unprecedented versatility and precision to every role.
          </p>
        </div>

        {/* Featured AI Stars */}
        <section className="space-y-6">
          <h2 className="text-2xl font-bold text-foreground">Featured AI Stars</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {aiStars.map((star) => (
              <div
                key={star.id}
                className="glass-card p-6 rounded-xl border overflow-hidden hover:bg-card/60 smooth-transition group"
              >
                <div className="relative mb-4 overflow-hidden rounded-lg">
                  <img
                    src={star.image}
                    alt={star.name}
                    className="w-full aspect-square object-cover group-hover:scale-110 smooth-transition"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent opacity-0 group-hover:opacity-100 smooth-transition" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2">{star.name}</h3>
                <p className="text-sm text-foreground/70 mb-4">{star.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-accent font-semibold">{star.appearances} Appearances</span>
                  <button className="glass-button px-3 py-1 rounded-lg text-sm font-semibold">
                    Follow
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* AI Generated Content */}
        <section className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-2">Featured Content</h2>
            <p className="text-foreground/60">Movies and series featuring our AI actors</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {aiMovies.map((movie) => (
              <ContentCard key={movie.id} {...movie} />
            ))}
          </div>
        </section>

        {/* Info Section */}
        <section className="glass-card border rounded-xl p-8 space-y-4">
          <h2 className="text-2xl font-bold text-foreground">About AI Stars</h2>
          <div className="space-y-4 text-foreground/80">
            <p>
              Our AI Stars represent the pinnacle of artificial intelligence in entertainment. Using advanced neural networks and machine learning, these digital performers can embody any character, emotion, or performance style.
            </p>
            <p>
              Unlike traditional actors, AI Stars offer unprecedented flexibility, consistency, and the ability to be reused across multiple productions while maintaining their unique presence and appeal.
            </p>
            <p>
              Each AI Star is trained on diverse performance data to deliver authentic, nuanced performances that captivate audiences worldwide.
            </p>
          </div>
        </section>
      </main>

      <MobileNav />
    </div>
  );
}
