'use client';

import { Header } from '@/components/Header';
import { MobileNav } from '@/components/MobileNav';
import { HeroBanner } from '@/components/HeroBanner';
import { ContentCarousel } from '@/components/ContentCarousel';
import { FeaturedGrid } from '@/components/FeaturedGrid';
import { trendingMovies, continueWatching, aiMovies, heroContent } from '@/lib/data';

export default function Page() {
  return (
    <div className="bg-background text-foreground">
      <Header />

      {/* Hero Banner - Full Width and Height */}
      <div className="w-screen relative left-1/2 right-1/2 -ml-[50vw] -mr-[50vw]">
        <HeroBanner {...heroContent} />
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 py-6 pb-24 md:pb-8">

        {/* Your Next Watch Carousel */}
        <ContentCarousel
          title="Your Next Watch"
          items={continueWatching}
          viewAllHref="/library"
        />

        {/* Trending Now Carousel */}
        <ContentCarousel
          title="Trending Now"
          subtitle="What everyone is watching right now"
          items={trendingMovies}
          viewAllHref="/movies"
        />

        {/* AI Generated Content */}
        <section className="space-y-6">
          <div>
            <h2 className="text-3xl font-bold text-foreground mb-2">AI Generated Originals</h2>
            <p className="text-foreground/60">Experience cinema created by artificial intelligence</p>
          </div>
          <ContentCarousel items={aiMovies} title="" />
        </section>

        {/* Featured Creators */}
        <section className="space-y-6">
          <div>
            <h2 className="text-3xl font-bold text-foreground mb-2">Featured Creators</h2>
            <p className="text-foreground/60">Follow the visionaries behind your favorite content</p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              {
                id: 'cr1',
                name: 'Alex Nova',
                image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop',
                followers: '2.5M',
              },
              {
                id: 'cr2',
                name: 'Maya Chen',
                image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop',
                followers: '1.8M',
              },
              {
                id: 'cr3',
                name: 'Isaac Moore',
                image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop',
                followers: '3.2M',
              },
              {
                id: 'cr4',
                name: 'Sophia Rivers',
                image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop',
                followers: '2.1M',
              },
            ].map((creator) => (
              <div
                key={creator.id}
                className="glass-card p-4 rounded-xl border text-center hover:bg-card/60 smooth-transition cursor-pointer"
              >
                <img
                  src={creator.image}
                  alt={creator.name}
                  className="w-20 h-20 rounded-full mx-auto mb-3 object-cover border-2 border-primary/30"
                />
                <h3 className="font-bold text-foreground">{creator.name}</h3>
                <p className="text-sm text-accent mt-1">{creator.followers}</p>
                <button className="mt-3 w-full glass-button py-2 rounded-lg text-sm font-semibold">
                  Follow
                </button>
              </div>
            ))}
          </div>
        </section>

        {/* Popular Content */}
        <FeaturedGrid title="More to Explore" items={trendingMovies.slice(0, 8)} />
      </main>

      <MobileNav />
    </div>
  );
}
