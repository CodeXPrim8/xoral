'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Play, Plus } from 'lucide-react';

interface ContentCardProps {
  id: string;
  title: string;
  image: string;
  rating?: number;
  type?: 'movie' | 'ai' | 'series';
  href?: string;
}

export function ContentCard({ id, title, image, rating, type = 'movie', href = '#' }: ContentCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  const cardContent = (
    <div
      className="group relative h-full overflow-hidden rounded cursor-pointer bg-card"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Image */}
      <div className="relative w-full aspect-[9/12] overflow-hidden bg-card">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover smooth-transition group-hover:scale-105"
        />
        
        {/* Badge */}
        {type === 'ai' && (
          <div className="netflix-badge">
            AI
          </div>
        )}
      </div>

      {/* Hover Overlay */}
      {isHovered && (
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent p-3 flex flex-col justify-end">
          <div className="space-y-2">
            <h3 className="font-bold text-foreground text-sm line-clamp-2">{title}</h3>
            {rating && (
              <p className="text-xs text-foreground/70 flex items-center gap-1">
                ★ {rating}/10
              </p>
            )}
            <button className="w-full glass-button py-1.5 px-2 rounded text-xs font-bold flex items-center justify-center gap-1">
              <Play className="w-3 h-3" />
              Play
            </button>
          </div>
        </div>
      )}
    </div>
  );

  if (href === '#') {
    return cardContent;
  }

  return (
    <Link href={href}>
      {cardContent}
    </Link>
  );
}
