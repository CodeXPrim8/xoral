'use client';

import Link from 'next/link';
import { Search, Bell } from 'lucide-react';

export function Header() {
  return (
    <header className="sticky top-0 z-50 bg-background/95 border-b border-border">
      <div className="w-full px-6 sm:px-8">
        <div className="flex items-center justify-between h-14">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 flex-shrink-0">
            <span className="text-red-600 text-2xl font-bold">NETFLIX</span>
          </Link>

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-6 ml-8">
            <Link href="/" className="text-sm text-foreground hover:text-foreground/70 smooth-transition">
              Home
            </Link>
            <Link href="/movies" className="text-sm text-foreground hover:text-foreground/70 smooth-transition">
              Movies
            </Link>
            <Link href="/search" className="text-sm text-foreground hover:text-foreground/70 smooth-transition">
              Shows
            </Link>
            <Link href="/library" className="text-sm text-foreground hover:text-foreground/70 smooth-transition">
              My List
            </Link>
            <Link href="/community" className="text-sm text-foreground hover:text-foreground/70 smooth-transition">
              New & Popular
            </Link>
          </nav>

          {/* Right Actions */}
          <div className="flex items-center gap-4 ml-auto">
            <button className="p-2 hover:opacity-70 smooth-transition hidden sm:block">
              <Search className="w-5 h-5 text-foreground" />
            </button>
            <button className="p-2 hover:opacity-70 smooth-transition relative">
              <Bell className="w-5 h-5 text-foreground" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-primary rounded-full" />
            </button>
            <Link
              href="/profile"
              className="flex items-center justify-center w-8 h-8 rounded bg-primary text-primary-foreground text-xs font-bold hover:opacity-70 smooth-transition"
            >
              M
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}
