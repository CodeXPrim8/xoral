// Sample data for XORA Studios

export const trendingMovies = [
  {
    id: '1',
    title: 'Nexus Protocol',
    image: 'https://images.unsplash.com/photo-1633356122544-f134324ef6db?w=400&h=600&fit=crop',
    rating: 9,
    type: 'movie' as const,
  },
  {
    id: '2',
    title: 'Cipher Origins',
    image: 'https://images.unsplash.com/photo-1598899134739-24c46f58b8c0?w=400&h=600&fit=crop',
    rating: 8.8,
    type: 'movie' as const,
  },
  {
    id: '3',
    title: 'Quantum Void',
    image: 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=400&h=600&fit=crop',
    rating: 8.5,
    type: 'movie' as const,
  },
  {
    id: '4',
    title: 'Digital Dreams',
    image: 'https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=400&h=600&fit=crop',
    rating: 8.3,
    type: 'movie' as const,
  },
  {
    id: '5',
    title: 'Synthetic Hearts',
    image: 'https://images.unsplash.com/photo-1516339901601-2e1b62dc0c45?w=400&h=600&fit=crop',
    rating: 8.7,
    type: 'movie' as const,
  },
  {
    id: '6',
    title: 'Parallax Universe',
    image: 'https://images.unsplash.com/photo-1626814026039-bff8b0b87fdb?w=400&h=600&fit=crop',
    rating: 8.4,
    type: 'movie' as const,
  },
];

export const continueWatching = [
  {
    id: 'c1',
    title: 'Nexus Protocol - Episode 5',
    image: 'https://images.unsplash.com/photo-1633356122544-f134324ef6db?w=400&h=600&fit=crop',
    rating: 9,
    type: 'series' as const,
  },
  {
    id: 'c2',
    title: 'Cipher Origins',
    image: 'https://images.unsplash.com/photo-1598899134739-24c46f58b8c0?w=400&h=600&fit=crop',
    rating: 8.8,
    type: 'movie' as const,
  },
  {
    id: 'c3',
    title: 'Digital Dreams - Season 2',
    image: 'https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=400&h=600&fit=crop',
    rating: 8.3,
    type: 'series' as const,
  },
  {
    id: 'c4',
    title: 'Synthetic Hearts',
    image: 'https://images.unsplash.com/photo-1516339901601-2e1b62dc0c45?w=400&h=600&fit=crop',
    rating: 8.7,
    type: 'movie' as const,
  },
];

export const aiMovies = [
  {
    id: 'ai1',
    title: 'AI Genesis',
    image: 'https://images.unsplash.com/photo-1677442d019cecf8978f0b86b87b13fb208b47f1?w=400&h=600&fit=crop',
    rating: 8.9,
    type: 'ai' as const,
  },
  {
    id: 'ai2',
    title: 'Neural Stories',
    image: 'https://images.unsplash.com/photo-1673976821596-4fbf35bd0c05?w=400&h=600&fit=crop',
    rating: 8.6,
    type: 'ai' as const,
  },
  {
    id: 'ai3',
    title: 'Algorithmic Dreams',
    image: 'https://images.unsplash.com/photo-1535016120754-188f50d75abc?w=400&h=600&fit=crop',
    rating: 8.4,
    type: 'ai' as const,
  },
  {
    id: 'ai4',
    title: 'Synthetic Worlds',
    image: 'https://images.unsplash.com/photo-1678062745911-65d4848daa40?w=400&h=600&fit=crop',
    rating: 8.8,
    type: 'ai' as const,
  },
  {
    id: 'ai5',
    title: 'Logic Realm',
    image: 'https://images.unsplash.com/photo-1530032623433-24a1a62c3e03?w=400&h=600&fit=crop',
    rating: 8.5,
    type: 'ai' as const,
  },
  {
    id: 'ai6',
    title: 'Data Consciousness',
    image: 'https://images.unsplash.com/photo-1620712014062-e2e1d5ca4718?w=400&h=600&fit=crop',
    rating: 8.7,
    type: 'ai' as const,
  },
];

export const creators = [
  {
    id: 'cr1',
    name: 'Alex Nova',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop',
    followers: '2.5M',
    specialization: 'Sci-Fi Cinema',
  },
  {
    id: 'cr2',
    name: 'Maya Chen',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop',
    followers: '1.8M',
    specialization: 'AI Narratives',
  },
  {
    id: 'cr3',
    name: 'Isaac Moore',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop',
    followers: '3.2M',
    specialization: 'Tech Thrillers',
  },
  {
    id: 'cr4',
    name: 'Sophia Rivers',
    image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop',
    followers: '2.1M',
    specialization: 'Futurism',
  },
];

export const heroContent = {
  title: 'Ashes to Crown',
  description: 'A general\'s daughter marries for love, only to lose her clan and her life. Reborn on her wedding eve, Chu Zhao vows to rewrite her fate and seize power.',
  rating: 16,
  category: 'Drama',
  image: '/hero-banner.png',
  subtitle: 'New Episodes Coming Wednesday',
};
